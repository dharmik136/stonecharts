"""Shared chart-spec model (Python view of spec/chart-spec.schema.json).

The spec is the language-agnostic 'recipe' for a chart: type, data, axes,
titles, colors, and (from the customization layer) styling. Keep this in lockstep
with spec/chart-spec.schema.json and libs/go/spec.go.
"""

from __future__ import annotations

from dataclasses import dataclass, field, fields

from .limits import enforce_spec_limits
from .util import esc
from .validate import SpecError, validate


def _opt_float(d: dict, key: str) -> float | None:
    """Float if the key is present (validation guarantees it's numeric), else None.

    This is NOT coercion: a default is supplied only when the key is ABSENT;
    malformed values are already rejected by validate() before we get here.
    """
    return float(d[key]) if key in d else None


def _normalize_datum(v: object, index: int) -> Datum:
    """Point-model normalization (scatter §3.3 Rank 3 / bubble §3.3 Rank 4,
    §5.4b lockstep).

    Bare number -> Datum(x=index, y=v) (the pinned fast path — must match Go's
    UnmarshalJSON byte-for-byte). Positional [x, y] / [x, y, z] and object
    {x, y} / {x, y, z} are sugar over the same datum; z stays None unless
    present (scatter never supplies it). validate() already rejected any
    other shape for the active chart type.
    """
    if isinstance(v, dict):
        z = float(v["z"]) if "z" in v else None
        return Datum(x=float(v["x"]), y=float(v["y"]), z=z)
    if isinstance(v, list):
        z = float(v[2]) if len(v) > 2 else None
        return Datum(x=float(v[0]), y=float(v[1]), z=z)
    return Datum(x=float(index), y=float(v))  # type: ignore[arg-type]


@dataclass
class Marker:
    enabled: bool = True
    symbol: str = "circle"  # circle | square | triangle | diamond
    radius: float = 3.5


@dataclass
class GradientStop:
    offset: float
    color: str
    opacity: float | None = None


@dataclass
class Gradient:
    """Linear gradient. Direction x1,y1 -> x2,y2 in 0..1 bounding-box coords."""

    stops: list[GradientStop]
    x1: float = 0.0
    y1: float = 0.0
    x2: float = 0.0
    y2: float = 1.0


@dataclass
class Pattern:
    type: str = "hatch"
    color: str = "#333333"
    background: str | None = None
    size: float = 8.0
    angle: float = 45.0
    stroke_width: float = 1.5


@dataclass
class Connector:
    enabled: bool = True
    dash_style: str = "dashed"


@dataclass
class Binning:
    count: int | None = None
    width: float | None = None
    start: float | None = None


@dataclass
class Datum:
    """One (x, y) or (x, y, z) observation — the scatter (§3.3 Rank 3) / bubble
    (§3.3 Rank 4) point model.

    Populated ONLY on Series.data_points, and only for chart type "scatter" or
    "bubble"; every other chart type continues to use Series.data (plain
    float y-values, x = category index) completely unchanged, so this
    addition carries zero byte-parity risk for line/column/area/bar. `z` is
    None for scatter (never supplied) and always set for bubble.
    """

    x: float
    y: float
    z: float | None = None


@dataclass
class Span:
    x: float
    x2: float
    y: int
    id: str | None = None
    name: str | None = None
    dependency: list[str] | None = None
    milestone: bool = False


@dataclass
class FrameDatum:
    x: float
    x2: float
    depth: int
    name: str | None = None
    color: str | None = None


@dataclass
class RangePoint:
    low: float
    high: float
    value: float | None = None
    category: str | None = None
    name: str | None = None


@dataclass
class BoxDatum:
    low: float
    q1: float
    median: float
    q3: float
    high: float
    outliers: list[float] = field(default_factory=list)


@dataclass
class Indicator:
    type: str
    period: int | None = None
    color: str | None = None
    dash_style: str | None = None
    params: dict | None = None
    pane: int | None = None


@dataclass
class TriangleData:
    origins: list[str]
    periods: list[int]
    values: list[list[float]]
    view: str = "cumulative"
    value_type: str = "incurred"
    unit: str = ""


@dataclass
class DiagonalConfig:
    highlight: bool = False
    label: str = ""


@dataclass
class FactorsConfig:
    show: bool = False
    values: list[float] = field(default_factory=list)


@dataclass
class ColorScaleConfig:
    scale_type: str = "sequential"
    domain: str = "auto"


@dataclass
class TriangleAnnotation:
    origin: str
    period: int
    text: str


@dataclass
class Flag:
    x: float
    title: str
    text: str | None = None
    color: str | None = None
    shape: str | None = None


@dataclass
class PlotBand:
    from_val: float
    to: float
    color: str
    label: str | None = None
    opacity: float | None = None


@dataclass
class PlotLine:
    value: float
    color: str
    width: float | None = None
    dash_style: str | None = None
    label: str | None = None


@dataclass
class GaugeBand:
    from_val: float
    to_val: float
    color: str


@dataclass
class Pane:
    height: float | None = None
    min: float | None = None
    max: float | None = None
    title: str | None = None
    plot_bands: list[PlotBand] | None = None
    plot_lines: list[PlotLine] | None = None


@dataclass
class Series:
    name: str
    data: list[float]
    type: str = "column"  # line | column (combo per-series mark kind)
    y_axis: int = 0  # 0 -> primary y_axis; 1 -> secondary_y_axis
    color: str | Gradient | None = None
    fill_opacity: float = 0.0  # >0 -> area fill under the line
    pattern: Pattern | None = None  # hatch fill for the area
    line_width: float | None = None  # None -> default 2
    dash_style: str = "solid"  # solid | dashed | dotted
    step: str | None = None  # None | before | after | center
    curve: str | None = None  # None/linear | monotone
    marker: Marker | None = None
    regression: bool = False
    low: list[float] | None = None
    high: list[float] | None = None
    range_data: list[RangePoint] | None = None
    data_points: list[Datum] | None = None  # scatter only — see Datum
    ohlc: list[dict] | None = None  # candlestick only — [{open,high,low,close}, ...]
    box_data: list[BoxDatum] | None = None  # boxplot only — 5-number summary per category
    widths: list[float] | None = None  # variwide only — per-datum width metric
    labels: list[str] | None = None  # timeline only — per-event label text
    x: list[float] | None = None  # vector-plot — per-point numeric x-coordinate
    z: list[float] | None = None  # variable-radius pie — per-slice radius metric
    direction: list[float] | None = None  # windbarb/vector-plot — per-point direction (degrees)
    length: list[float] | None = None  # vector-plot only — per-point magnitude
    spans: list[Span] | None = None  # xrange/Gantt — per-series span objects
    frames: list[FrameDatum] | None = None  # flame-chart — per-series call frames
    volume: list[float] | None = None
    indicators: list[Indicator] | None = None


@dataclass
class GridLine:
    enabled: bool = True
    color: str | None = None  # None -> theme/default (#e8e8ee)
    dash_style: str = "solid"  # solid | dashed | dotted


@dataclass
class Axis:
    title: str | None = None
    categories: list[str] | None = None
    min: float | None = None
    max: float | None = None
    grid_line: GridLine | None = None  # yAxis always; xAxis only meaningful for scatter's numeric x

    opposite: bool | None = None  # secondaryYAxis only

    bin_edges: list[float] | None = None  # xAxis only (histogram bins)
    plot_bands: list[PlotBand] | None = None
    plot_lines: list[PlotLine] | None = None


@dataclass
class Margin:
    top: float | None = None
    right: float | None = None
    bottom: float | None = None
    left: float | None = None


@dataclass
class Layout:
    margin: Margin | None = None


@dataclass
class Theme:
    """Concrete color set (canonical values in spec/themes/*.json). Defaults = light,
    exactly reproducing the classic look so light output is byte-identical."""

    name: str = "light"
    background: str | None = None
    title_color: str = "#1a1a2e"
    subtitle_color: str = "#6b6b80"
    axis_label_color: str = "#6b6b80"
    axis_title_color: str = "#4a4a5a"
    grid_color: str = "#e8e8ee"
    axis_line_color: str = "#b6b6c2"
    crosshair_color: str = "#c0c0cc"
    marker_halo: str = "#fff"
    legend_text_color: str = "#33334d"
    palette: list[str] = field(
        default_factory=lambda: [
            "#2f7ed8",
            "#f45b5b",
            "#8bbc21",
            "#e4a812",
            "#1aadce",
            "#8e44ad",
            "#f28f43",
            "#77a1e5",
        ]
    )


# Built-in themes (baked; kept in lockstep with spec/themes/*.json by a parity test).
THEMES = {
    "light": Theme(),
    "dark": Theme(
        name="dark",
        background="#1a1a2e",
        title_color="#f5f5fa",
        subtitle_color="#a0a0b8",
        axis_label_color="#9a9ab0",
        axis_title_color="#c8c8d8",
        grid_color="#2e2e44",
        axis_line_color="#45455a",
        crosshair_color="#55556a",
        marker_halo="#1a1a2e",
        legend_text_color="#d0d0e0",
        palette=[
            "#5aa2f0",
            "#ff7a7a",
            "#a3d95a",
            "#f5c542",
            "#3ec8e0",
            "#b57ae0",
            "#ff9d5c",
            "#93b8ff",
        ],
    ),
}

# camelCase JSON key -> Theme attribute (for custom-object overrides + JSON parity).
_THEME_KEYS = {
    "background": "background",
    "titleColor": "title_color",
    "subtitleColor": "subtitle_color",
    "axisLabelColor": "axis_label_color",
    "axisTitleColor": "axis_title_color",
    "gridColor": "grid_color",
    "axisLineColor": "axis_line_color",
    "crosshairColor": "crosshair_color",
    "markerHalo": "marker_halo",
    "legendTextColor": "legend_text_color",
    "palette": "palette",
}


def resolve_theme(value) -> Theme:
    """A theme name, a custom object (overriding a named base), or None -> light."""
    if value is None:
        return THEMES["light"]
    if isinstance(value, str):
        return THEMES.get(value, THEMES["light"])
    if isinstance(value, dict):
        base = THEMES.get(value.get("name", "light"), THEMES["light"])
        t = Theme(**{f.name: getattr(base, f.name) for f in fields(base)})
        t.name = value.get("name", base.name)
        # Custom theme values are user input -> escape so a hostile color can't
        # break out of the SVG attribute it lands in.
        for k, attr in _THEME_KEYS.items():
            if k in value:
                v = value[k]
                if attr == "palette":
                    if isinstance(v, list) and len(v) > 0:
                        setattr(t, attr, [esc(c) for c in v])
                elif v is None:
                    setattr(t, attr, None)
                else:
                    setattr(t, attr, esc(v))
        return t
    return THEMES["light"]


@dataclass
class ChartSpec:
    series: list[Series]
    type: str = "line"
    id: str = "sc"
    theme: Theme = field(default_factory=lambda: THEMES["light"])
    title: str | None = None
    subtitle: str | None = None
    x_axis: Axis = field(default_factory=Axis)
    y_axis: Axis = field(default_factory=Axis)
    secondary_y_axis: Axis | None = None

    binning: Binning | None = None

    pre_binned: bool = False

    def __post_init__(self) -> None:
        """Point-model normalization for the typed-construction path (scatter
        §3.3 Rank 3 / bubble §3.3 Rank 4): from_dict() normalizes
        data_points itself before the Series objects exist, but a caller
        building ChartSpec/Series directly (see charts/scatter/design.md
        "Generate it - typed") never goes through from_dict, so it lands
        here instead. Guarded by `data_points is None` so from_dict's own
        already-normalized series are never touched twice.
        """
        if self.type in ("scatter", "bubble"):
            for s in self.series:
                if s.data_points is None:
                    s.data_points = [_normalize_datum(v, i) for i, v in enumerate(s.data)]
                    s.data = []

    normalization: str = "frequency"

    overlay: str | None = None

    subtype: str | None = None  # candlestick: candlestick|ohlc|hlc|heikin-ashi|hollow
    up_color: str = "#3f9b6a"  # candlestick up (close >= open) color
    down_color: str = "#d65f5f"  # candlestick down (close < open) color

    width: int = 820
    height: int = 460
    legend: bool = True
    responsive: bool = False
    a11y: bool = True
    layout: Layout | None = None
    stacking: str | None = None  # None | "normal" | "percent"
    grouping: bool = True  # True = grouped side-by-side; False = overlaid
    orientation: str | None = None  # None -> "vertical"; "horizontal" for bar-range
    total_color: str = "#4b6cb7"
    sum_indices: list[int] | None = None
    intermediate_sum_indices: list[int] | None = None
    connector: Connector | None = None
    bullet_target: float | None = None
    bullet_ranges: list[float] | None = None
    neck_width: float = 0.3
    neck_height: float = 0.25
    min_width: float = 0.0
    speed_unit: str = "kt"
    calm_threshold: float = 2.0
    hemisphere: str = "N"
    barb_length: float = 20.0
    y_offset: float = 0.0
    offset: str = "wiggle"  # streamgraph baseline: "wiggle" | "silhouette"
    vector_length: float = 20.0
    rotation_origin: str = "center"
    inner_size: float = 0.0  # pie/donut: inner radius as fraction of outer (0 = pie, >0 = donut)
    min_size: float = 0.2  # variable-radius pie: minimum slice radius as fraction of max
    gauge_min: float = 0.0  # gauge: scale minimum
    gauge_max: float = 100.0  # gauge: scale maximum
    gauge_bands: list[GaugeBand] | None = None  # gauge: colored range bands
    out_of_range: str = "error"  # histogram: "error" | "clip"
    flags: list[Flag] | None = None
    panes: list[Pane] | None = None
    triangle: TriangleData | None = None
    diagonal: DiagonalConfig | None = None
    factors_config: FactorsConfig | None = None
    color_scale: ColorScaleConfig | None = None
    triangle_annotations: list[TriangleAnnotation] | None = None

    @staticmethod
    def from_dict(d: dict, *, raw_size_hint: int | None = None) -> ChartSpec:
        """Build a ChartSpec from a plain dict (parsed JSON).

        The dict is validated first (same rules as the Go renderer); a malformed
        spec raises SpecError. Unknown keys are ignored. Values are trusted after
        validation, so parsing does no coercion — defaults apply only on absence.
        """
        enforce_spec_limits(d, raw_size_hint=raw_size_hint)
        errs = validate(d)
        if errs:
            raise SpecError(errs)
        chart_type = d.get("type") or "line"
        series = []
        for i, s in enumerate(d.get("series", [])):
            m = s.get("marker")
            marker = None
            if m is not None:
                r = float(m.get("radius", 3.5))
                marker = Marker(
                    enabled=m.get("enabled", True),
                    symbol=m.get("symbol") or "circle",
                    radius=r if r != 0.0 else 3.5,
                )
            c = s.get("color")
            if isinstance(c, dict):
                color: str | Gradient | None = Gradient(
                    # Keep every stop (missing offset -> 0.0, color -> "") so this
                    # matches Go's decoder byte-for-byte; do NOT drop partial stops.
                    stops=[
                        GradientStop(
                            offset=float(st.get("offset", 0.0)),
                            color=st.get("color", ""),
                            opacity=_opt_float(st, "opacity"),
                        )
                        for st in c.get("stops", [])
                    ],
                    x1=float(c.get("x1", 0.0)),
                    y1=float(c.get("y1", 0.0)),
                    x2=float(c.get("x2", 0.0)),
                    y2=float(c.get("y2", 1.0)),
                )
            else:
                color = c
            p = s.get("pattern")
            pattern = None
            if p is not None:
                pattern = Pattern(
                    type=p.get("type") or "hatch",
                    color=p.get("color") or "#333333",
                    background=p.get("background"),
                    size=float(p.get("size", 8.0)),
                    angle=float(p.get("angle", 45.0)),
                    stroke_width=float(p.get("strokeWidth", 1.5)),
                )
            if chart_type in ("scatter", "bubble"):
                data_points = [_normalize_datum(v, j) for j, v in enumerate(s["data"])]
                data_field: list[float] = []
            elif "data" not in s:
                data_points = None
                data_field = []
            else:
                data_points = None
                data_field = [float(v) for v in s["data"]]
            box_data_raw = s.get("boxData")
            box_data = None
            if isinstance(box_data_raw, list):
                box_data = [
                    BoxDatum(
                        low=float(bd["low"]),
                        q1=float(bd["q1"]),
                        median=float(bd["median"]),
                        q3=float(bd["q3"]),
                        high=float(bd["high"]),
                        outliers=[float(v) for v in bd.get("outliers", [])],
                    )
                    for bd in box_data_raw
                ]
            indicators_raw = s.get("indicators")
            indicators = None
            if indicators_raw:
                indicators = [
                    Indicator(
                        type=ind["type"],
                        period=ind.get("period"),
                        color=ind.get("color"),
                        dash_style=ind.get("dashStyle"),
                        params=ind.get("params"),
                        pane=ind.get("pane"),
                    )
                    for ind in indicators_raw
                ]
            range_data_raw = s.get("rangeData")
            range_data_list = None
            if isinstance(range_data_raw, list) and len(range_data_raw) > 0:
                range_data_list = [
                    RangePoint(
                        low=float(rp["low"]),
                        high=float(rp["high"]),
                        value=float(rp["value"]) if "value" in rp else None,
                        category=rp.get("category"),
                        name=rp.get("name"),
                    )
                    for rp in range_data_raw
                ]
                if chart_type == "arearange":
                    data_field = [rp.high for rp in range_data_list]
                    low_field: list[float] | None = [rp.low for rp in range_data_list]
                    high_field: list[float] | None = None
                elif chart_type == "error-bar":
                    data_field = [rp.value for rp in range_data_list]  # type: ignore[misc]
                    low_field = [rp.low for rp in range_data_list]
                    high_field = [rp.high for rp in range_data_list]
                else:  # columnrange, dumbbell
                    data_field = [rp.low for rp in range_data_list]
                    low_field = None
                    high_field = [rp.high for rp in range_data_list]
            else:
                low_field = [float(v) for v in s["low"]] if "low" in s and s["low"] is not None else None
                high_field = [float(v) for v in s["high"]] if "high" in s and s["high"] is not None else None
            series.append(
                Series(
                    name=s.get("name") or f"Series {i + 1}",
                    data=data_field,
                    data_points=data_points,
                    type=s.get("type") or "column",
                    y_axis=int(s.get("yAxis", 0)),
                    color=color,
                    fill_opacity=float(s.get("fillOpacity", 0.0)),
                    pattern=pattern,
                    line_width=_opt_float(s, "lineWidth"),
                    dash_style=s.get("dashStyle") or "solid",
                    step=s.get("step"),
                    curve=s.get("curve"),
                    marker=marker,
                    regression=bool(s.get("regression", False)),
                    low=low_field,
                    high=high_field,
                    range_data=range_data_list,
                    ohlc=s.get("ohlc"),
                    box_data=box_data,
                    widths=[float(v) for v in s["widths"]] if "widths" in s and s["widths"] is not None else None,
                    labels=[str(v) for v in s["labels"]] if "labels" in s and s["labels"] is not None else None,
                    x=[float(v) for v in s["x"]] if "x" in s and s["x"] is not None else None,
                    z=[float(v) for v in s["z"]] if "z" in s and s["z"] is not None else None,
                    direction=[float(v) for v in s["direction"]]
                    if "direction" in s and s["direction"] is not None
                    else None,
                    length=[float(v) for v in s["length"]] if "length" in s and s["length"] is not None else None,
                    spans=[
                        Span(
                            x=float(sp["x"]),
                            x2=float(sp["x2"]),
                            y=int(sp["y"]),
                            id=sp.get("id"),
                            name=sp.get("name"),
                            dependency=sp.get("dependency"),
                            milestone=bool(sp.get("milestone", False)),
                        )
                        for sp in s["spans"]
                    ]
                    if "spans" in s and s["spans"] is not None
                    else None,
                    frames=[
                        FrameDatum(
                            x=float(fr["x"]),
                            x2=float(fr["x2"]),
                            depth=int(fr["depth"]),
                            name=fr.get("name"),
                            color=fr.get("color"),
                        )
                        for fr in s["frames"]
                    ]
                    if "frames" in s and s["frames"] is not None
                    else None,
                    volume=s.get("volume"),
                    indicators=indicators,
                )
            )
        xa = d.get("xAxis") or {}
        ya = d.get("yAxis") or {}
        sy = d.get("secondaryYAxis")

        bn = d.get("binning")
        binning = None
        if bn is not None:
            binning = Binning(
                count=int(bn["count"]) if "count" in bn and bn["count"] is not None else None,
                width=_opt_float(bn, "width"),
                start=_opt_float(bn, "start"),
            )

        grid = None
        gl = ya.get("gridLine")
        if gl is not None:
            grid = GridLine(
                enabled=gl.get("enabled", True),
                color=gl.get("color"),
                dash_style=gl.get("dashStyle", "solid"),
            )

        # xAxis.gridLine (scatter's numeric x only; default OFF, unlike yAxis's
        # default-ON — an explicit object always wins, matching yAxis's pattern).
        xgrid = None
        xgl = xa.get("gridLine")
        if xgl is not None:
            xgrid = GridLine(
                enabled=xgl.get("enabled", False),
                color=xgl.get("color"),
                dash_style=xgl.get("dashStyle", "solid"),
            )

        layout = None
        ly = d.get("layout")
        if ly is not None:
            m = ly.get("margin")
            margin = None
            if m is not None:
                margin = Margin(
                    top=_opt_float(m, "top"),
                    right=_opt_float(m, "right"),
                    bottom=_opt_float(m, "bottom"),
                    left=_opt_float(m, "left"),
                )
            layout = Layout(margin=margin)

        secondary = None
        if sy is not None:
            sgrid = None
            sgl = sy.get("gridLine")
            if sgl is not None:
                sgrid = GridLine(
                    enabled=sgl.get("enabled", True),
                    color=sgl.get("color"),
                    dash_style=sgl.get("dashStyle", "solid"),
                )
            secondary = Axis(
                title=sy.get("title"),
                min=_opt_float(sy, "min"),
                max=_opt_float(sy, "max"),
                grid_line=sgrid,
                opposite=sy.get("opposite", True),
            )
        conn_raw = d.get("connector")
        connector_obj = None
        if conn_raw is not None and isinstance(conn_raw, dict):
            connector_obj = Connector(
                enabled=conn_raw.get("enabled", True),
                dash_style=conn_raw.get("dashStyle", "dashed"),
            )

        def _parse_plot_bands(raw):
            if not raw:
                return None
            return [
                PlotBand(
                    from_val=float(pb["from"]),
                    to=float(pb["to"]),
                    color=pb["color"],
                    label=pb.get("label"),
                    opacity=pb.get("opacity"),
                )
                for pb in raw
            ]

        def _parse_plot_lines(raw):
            if not raw:
                return None
            return [
                PlotLine(
                    value=float(pl["value"]),
                    color=pl["color"],
                    width=pl.get("width"),
                    dash_style=pl.get("dashStyle"),
                    label=pl.get("label"),
                )
                for pl in raw
            ]

        flags_raw = d.get("flags")
        flags = None
        if flags_raw:
            flags = [
                Flag(
                    x=float(fl["x"]),
                    title=fl["title"],
                    text=fl.get("text"),
                    color=fl.get("color"),
                    shape=fl.get("shape"),
                )
                for fl in flags_raw
            ]

        panes_raw = d.get("panes")
        panes = None
        if panes_raw:
            panes = [
                Pane(
                    height=p.get("height"),
                    min=p.get("min"),
                    max=p.get("max"),
                    title=p.get("title"),
                    plot_bands=_parse_plot_bands(p.get("plotBands")),
                    plot_lines=_parse_plot_lines(p.get("plotLines")),
                )
                for p in panes_raw
            ]

        return ChartSpec(
            series=series,
            type=d.get("type") or "line",
            id=d.get("id") or "sc",
            theme=resolve_theme(d.get("theme")),
            title=d.get("title"),
            subtitle=d.get("subtitle"),
            x_axis=Axis(
                title=xa.get("title"),
                categories=xa.get("categories"),
                min=_opt_float(xa, "min"),
                max=_opt_float(xa, "max"),
                bin_edges=xa.get("binEdges"),
                grid_line=xgrid,
                plot_bands=_parse_plot_bands(xa.get("plotBands")),
                plot_lines=_parse_plot_lines(xa.get("plotLines")),
            ),
            y_axis=Axis(
                title=ya.get("title"),
                categories=ya.get("categories"),
                min=_opt_float(ya, "min"),
                max=_opt_float(ya, "max"),
                grid_line=grid,
                plot_bands=_parse_plot_bands(ya.get("plotBands")),
                plot_lines=_parse_plot_lines(ya.get("plotLines")),
            ),
            secondary_y_axis=secondary,
            binning=binning,
            pre_binned=bool(d.get("preBinned", False)),
            normalization=d.get("normalization") or "frequency",
            overlay=d.get("overlay"),
            subtype=d.get("subtype"),
            up_color=d.get("upColor") or "#3f9b6a",
            down_color=d.get("downColor") or "#d65f5f",
            width=int(d.get("width", 820)),
            height=int(d.get("height", 460)),
            legend=bool(d.get("legend", True)),
            responsive=bool(d.get("responsive", False)),
            a11y=bool(d.get("a11y", True)),
            layout=layout,
            stacking=d.get("stacking"),
            grouping=bool(d.get("grouping", True)),
            orientation=d.get("orientation"),
            total_color=d.get("totalColor") or "#4b6cb7",
            sum_indices=[int(v) for v in d.get("sumIndices", [])] or None,
            intermediate_sum_indices=[int(v) for v in d.get("intermediateSumIndices", [])] or None,
            connector=connector_obj,
            bullet_target=_opt_float(d, "bulletTarget"),
            bullet_ranges=[float(v) for v in d["bulletRanges"]]
            if "bulletRanges" in d and isinstance(d.get("bulletRanges"), list)
            else None,
            neck_width=float(d.get("neckWidth", 0.3)),
            neck_height=float(d.get("neckHeight", 0.25)),
            min_width=float(d.get("minWidth", 0.0)),
            speed_unit=d.get("speedUnit") or "kt",
            calm_threshold=float(d.get("calmThreshold", 2)),
            hemisphere=d.get("hemisphere") or "N",
            barb_length=float(d.get("barbLength", 20)),
            y_offset=float(d.get("yOffset", 0)),
            offset=d.get("offset") or "wiggle",
            vector_length=float(d.get("vectorLength", 20)),
            rotation_origin=d.get("rotationOrigin") or "center",
            inner_size=float(d.get("innerSize", 0)),
            min_size=float(d.get("minSize", 0.2)),
            gauge_min=float(d.get("gaugeMin", 0)),
            gauge_max=float(d.get("gaugeMax", 100)),
            gauge_bands=[
                GaugeBand(
                    from_val=float(b["from"]),
                    to_val=float(b["to"]),
                    color=str(b["color"]),
                )
                for b in d["gaugeBands"]
            ]
            if d.get("gaugeBands")
            else None,
            out_of_range=d.get("outOfRange") or "error",
            flags=flags,
            panes=panes,
            triangle=TriangleData(
                origins=[str(o) for o in d["triangle"]["origins"]],
                periods=[int(p) for p in d["triangle"]["periods"]],
                values=[[float(v) for v in row] for row in d["triangle"]["values"]],
                view=d["triangle"].get("view") or "cumulative",
                value_type=d["triangle"].get("valueType") or "incurred",
                unit=d["triangle"].get("unit") or "",
            )
            if isinstance(d.get("triangle"), dict)
            else None,
            diagonal=DiagonalConfig(
                highlight=bool(d["diagonal"].get("highlight", False)),
                label=d["diagonal"].get("label") or "",
            )
            if isinstance(d.get("diagonal"), dict)
            else None,
            factors_config=FactorsConfig(
                show=bool(d["factors"].get("show", False)),
                values=[float(v) for v in d["factors"].get("values", [])],
            )
            if isinstance(d.get("factors"), dict)
            else None,
            color_scale=ColorScaleConfig(
                scale_type=d["colorScale"].get("type") or "sequential",
                domain=d["colorScale"].get("domain") or "auto",
            )
            if isinstance(d.get("colorScale"), dict)
            else None,
            triangle_annotations=[
                TriangleAnnotation(
                    origin=str(a["origin"]),
                    period=int(a["period"]),
                    text=str(a["text"]),
                )
                for a in d["annotations"]
            ]
            if isinstance(d.get("annotations"), list)
            else None,
        )
